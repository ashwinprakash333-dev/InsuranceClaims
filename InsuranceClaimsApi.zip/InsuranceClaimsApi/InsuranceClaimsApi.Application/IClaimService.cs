﻿using InsuranceClaimsApi.Domain;

namespace InsuranceClaimsApi.Application
{
	public interface IClaimService
	{
		Task<IEnumerable<Claim>> GetAllAsync();
		Task<Claim?> GetByIdAsync(Guid id);
		Task SubmitAsync(Claim claim);
		Task<bool> UpdateStatusAsync(Guid id, ClaimStatus newStatus);
	}
}
