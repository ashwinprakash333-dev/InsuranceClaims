using InsuranceClaimsApi.Application;
using InsuranceClaimsApi.Domain;
using Microsoft.AspNetCore.Mvc;

namespace InsuranceClaimsApi.API.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class ClaimsController : ControllerBase
	{
		private readonly IClaimService _service;
		private readonly ILogger<ClaimsController> _logger;

		public ClaimsController(IClaimService service, ILogger<ClaimsController> logger)
		{
			_service = service;
			_logger = logger;
		}

		[HttpGet]
		public async Task<IActionResult> Get() => Ok(await _service.GetAllAsync());

		[HttpGet("{id}")]
		public async Task<IActionResult> GetById(Guid id)
		{
			var claim = await _service.GetByIdAsync(id);
			if (claim == null) return NotFound();
			return Ok(claim);
		}

		[HttpPost]
		public async Task<IActionResult> Submit([FromBody] Claim claim)
		{
			await _service.SubmitAsync(claim);
			return CreatedAtAction(nameof(GetById), new { id = claim.Id }, claim);
		}
		[HttpPost]
		public async Task<IActionResult> Submit1_test([FromBody] Claim claim)
		{
			await _service.SubmitAsync(claim);
			return CreatedAtAction(nameof(GetById), new { id = claim.Id }, claim);
		}

		[HttpPut("{id}/status")]
		public async Task<IActionResult> UpdateStatus(Guid id, [FromQuery] ClaimStatus status)
		{
			var success = await _service.UpdateStatusAsync(id, status);
			if (!success) return NotFound();
			return NoContent();
		}
	}
}
