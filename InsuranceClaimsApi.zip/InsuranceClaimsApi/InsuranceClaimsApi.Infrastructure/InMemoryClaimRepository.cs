﻿using InsuranceClaimsApi.Application;
using InsuranceClaimsApi.Domain;

namespace InsuranceClaimsApi.Infrastructure
{
	public class InMemoryClaimRepository : IClaimService
	{
		private readonly List<Claim> _claims = new();

		public Task<IEnumerable<Claim>> GetAllAsync() => Task.FromResult(_claims.AsEnumerable());
		public Task<Claim?> GetByIdAsync(Guid id) => Task.FromResult(_claims.FirstOrDefault(c => c.Id == id));
		public Task SubmitAsync(Claim claim) { _claims.Add(claim); return Task.CompletedTask; }

		public Task<bool> UpdateStatusAsync(Guid id, ClaimStatus newStatus)
		{
			var claim = _claims.FirstOrDefault(c => c.Id == id);
			if (claim is null) return Task.FromResult(false);
			claim.Status = newStatus;
			return Task.FromResult(true);
		}
	}
}
