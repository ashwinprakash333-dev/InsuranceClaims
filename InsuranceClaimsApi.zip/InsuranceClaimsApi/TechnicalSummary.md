Technologies Used

ASP.NET Core 7 Web API

Entity Framework Core (InMemory DB)

Swagger for API documentation

xUnit + Moq for unit testing

Clean Architecture principles

Dependency Injection

Repository Pattern