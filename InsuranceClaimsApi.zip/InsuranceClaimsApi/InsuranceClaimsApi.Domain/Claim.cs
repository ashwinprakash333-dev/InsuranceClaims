﻿namespace InsuranceClaimsApi.Domain
{
	public class Claim
	{
		public Guid Id { get; set; } = Guid.NewGuid();
		public string PolicyHolder { get; set; } = string.Empty;
		public string Description { get; set; } = string.Empty;
		public decimal Amount { get; set; }
		public ClaimStatus Status { get; set; } = ClaimStatus.Pending;
		public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
	}
}
