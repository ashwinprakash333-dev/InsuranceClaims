﻿namespace InsuranceClaimsApi.Domain
{
	public enum ClaimStatus
	{
		Pending,
		Approved,
		Rejected
	}
}
