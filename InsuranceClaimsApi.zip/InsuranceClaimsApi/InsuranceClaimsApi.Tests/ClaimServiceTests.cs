using InsuranceClaimsApi.Domain;
using InsuranceClaimsApi.Infrastructure;
using Xunit;

namespace InsuranceClaimsApi.Tests
{
	public class ClaimServiceTests
	{
		private readonly InMemoryClaimRepository _repo;

		public ClaimServiceTests()
		{
			_repo = new InMemoryClaimRepository();
		}

		[Fact]
		public async Task SubmitClaim_ShouldBeRetrievable()
		{
			var claim = new Claim { PolicyHolder = "Ashwin", Amount = 1000 };
			await _repo.SubmitAsync(claim);
			var result = await _repo.GetByIdAsync(claim.Id);
			Assert.NotNull(result);
			Assert.Equal("Ashwin", result!.PolicyHolder);
		}

		[Fact]
		public async Task UpdateStatus_ShouldChangeStatus()
		{
			var claim = new Claim { PolicyHolder = "Test", Amount = 100 };
			await _repo.SubmitAsync(claim);
			var updated = await _repo.UpdateStatusAsync(claim.Id, ClaimStatus.Approved);
			var result = await _repo.GetByIdAsync(claim.Id);
			Assert.True(updated);
			Assert.Equal(ClaimStatus.Approved, result!.Status);
		}
	}
}
