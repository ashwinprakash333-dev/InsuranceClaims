 Insurance Claims API
This is a sample .NET Web API built in 2 hours as part of a backend coding evaluation. It allows basic operations for managing insurance claims.